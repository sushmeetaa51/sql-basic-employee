-- Basic queries
SELECT * FROM employees;

-- Filter by job title
SELECT emp_id, emp_name, salary FROM employees WHERE job_title = 'Developer';

-- Order by salary
SELECT emp_name, job_title, salary FROM employees ORDER BY salary DESC;
