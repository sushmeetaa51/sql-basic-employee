-- Update Rahul's salary
UPDATE employees SET salary = 60000 WHERE emp_name = 'Rahul Kumar';
COMMIT;

-- Delete Priya
DELETE FROM employees WHERE emp_name = 'Priya Singh';
COMMIT;

-- Check results
SELECT * FROM employees;
