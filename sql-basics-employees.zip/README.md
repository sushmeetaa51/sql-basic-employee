# SQL Basics — Employees Demo (Beginner Friendly)

This tiny project helps you learn **pure SQL** step by step and push your first code to **GitHub**.

## What's inside
- `create_table.sql` — creates `employees` table
- `insert_data.sql` — inserts sample rows
- `queries.sql` — select queries
- `update_delete.sql` — update and delete examples
- `run_all.sql` — runs everything in order

## How to run (SQL Developer / SQL*Plus)
1. Connect to your Oracle schema.
2. Execute in this order (or run `@run_all.sql`):
   ```sql
   @create_table.sql
   @insert_data.sql
   @queries.sql
   @update_delete.sql
   ```
3. Re-run as many times as you want. If you see "table exists" errors, drop the table first:
   ```sql
   DROP TABLE employees PURGE;
   ```

## Next steps
- Add more columns (e.g., department).
- Write a view for high-salary employees.
- Document your changes in this README in your own words.
