-- Insert a few sample rows
INSERT INTO employees (emp_name, job_title, salary) VALUES ('Rahul Kumar', 'Developer', 55000);
INSERT INTO employees (emp_name, job_title, salary) VALUES ('Priya Singh', 'Tester', 45000);
INSERT INTO employees (emp_name, job_title, salary) VALUES ('Anita Rao', 'Developer', 62000);
COMMIT;
